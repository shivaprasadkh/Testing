package CheckBoxesDemo;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class CheckBox {

	public static void main(String[] args) {
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.get("https://itera-qa.azurewebsites.net/home/automation");
		driver.manage().window().maximize();
		
		// 1 specific checkbox
		 WebElement singleCheckBox = driver.findElement(By.xpath("//label[normalize-space()='Monday']"));
		 boolean isselected = singleCheckBox.isSelected();
		 
		 if(isselected == false) {
			 singleCheckBox.click();
		 }
		
		//2 Select all the check boxes
		List<WebElement> TotalCheckBox = driver.findElements(By.xpath("//input[@type='checkbox' and contains(@id,'day')]"));
		System.out.println("Total number of CheckBoxes="+TotalCheckBox.size());
		
//		for(int i = 0; i<TotalCheckBox.size();i++)
//		{
//			TotalCheckBox.get(i).click();
//		}
		
//		for(WebElement check: TotalCheckBox) {
//			check.click();
//		}
		
		// Based on my choice select 
//		for( WebElement check :TotalCheckBox) {
//			
//			String nameofweek = check.getAttribute("id");
//			if(nameofweek.equalsIgnoreCase("Saturday") || nameofweek.equalsIgnoreCase("Sunday")) {
//				check.click();
//			}
//		}

		
//		int checkBoxes = TotalCheckBox.size();
//		for(int i = checkBoxes-2; i<checkBoxes;i++) {
//			TotalCheckBox.get(i).click();
//		}
		
		
		
		
		
		

	}

}

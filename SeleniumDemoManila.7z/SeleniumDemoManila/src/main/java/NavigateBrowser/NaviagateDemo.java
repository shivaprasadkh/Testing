package NavigateBrowser;
/*Get() is used to naviagate perticuler (website) and wait till page load driver
 * navigate.to() is used to navigate to perticuler url and does not wait to page load
 * 	-->it maintains history or cookies to navigate back or forward
 * 
 * The only difference is that can be found in the parameter
 * get() accepts only one string parameter 
 * navigate.to() accepts String parameter and URL instance as parameter
 * 
 */
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class NaviagateDemo {

	public static void main(String[] args) {
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://www.flipkart.com/");
		//driver.get("https://www.amazon.com/");
		
		driver.navigate().to("https://www.amazon.com/");
		
		driver.navigate().back();
		driver.navigate().forward();
		
		driver.navigate().refresh();
	}

}

package WindowHandle;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class SwitchingWindows {

	public static void main(String[] args) throws Exception {
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();

		driver.get("https://demo.automationtesting.in/Windows.html");

		String ParentHandle = driver.getWindowHandle();
		System.out.println("Parent Window:=" + ParentHandle);

		driver.findElement(By.xpath("//a[contains(text(),'Open New Tabbed Windows')]")).click();
		driver.findElement(By.xpath("//button[starts-with(text(),'    click   ')]")).click();
		Thread.sleep(3000);
//		driver.switchTo().window(ParentHandle);
//		System.out.println(driver.getTitle());
		
		Set<String> ChildHandle = driver.getWindowHandles();
		
//		for(String handle : ChildHandle) {
//			System.out.println(handle);
//			
//			if(!handle.equals(ParentHandle)) {
//				Thread.sleep(3000);
//				
//				driver.switchTo().window(handle);
//				driver.findElement(By.linkText("Downloads")).click();
//			}
//						
//		}
		
		for( String handle : ChildHandle) {
			System.out.println(handle);
			String child1 = driver.switchTo().window(handle).getTitle();
			System.out.println(child1);
			
			if(child1.contains("Selenium")) {
				driver.close();
			}
			
		}

	}

}

package FindElements;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class FindElementsDemo {

	public static void main(String[] args) throws Exception {
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://demo.nopcommerce.com/");
		Thread.sleep(3000);
		
		//Find Element() --Returning single element
		//1
//		 WebElement  ele = driver.findElement(By.xpath("//input[@id='small-searchterms']"));//.sendKeys("Apple");
//		ele.sendKeys("apple");
		
		
		//2
//		WebElement ele1 = driver.findElement(By.xpath("//div[@class='footer-upper']//a"));
//		System.out.println(ele1.getText());
		
		//3
		//driver.findElement(By.xpath("//button[normalize-space()='Searc']")).click();
		//noSuchElementsException
		
		
		//FindElements() --Returns multiple web elements
		//1
//		List<WebElement> elements = driver.findElements(By.xpath(" //div[@class='footer-upper']//a"));
//		System.out.println("Number of elements are:="+elements.size());
//		
//		for(WebElement ele : elements) {
//			System.out.println(ele.getText());
//		}
		
		//2
//		List<WebElement> logo = driver.findElements(By.xpath("//img[@alt='nopCommerce demo store']"));
//		System.out.println("Number of elements are:="+logo.size());
		
		//3
		List<WebElement> logo = driver.findElements(By.xpath("//img[@alt='nopCommerce demo stor']"));
		System.out.println("Number of elements are:="+logo.size());
		
		
			
	}

}

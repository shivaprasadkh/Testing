package DatePicker;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import io.github.bonigarcia.wdm.WebDriverManager;

public class DatePicker_DropDown {

	public static void main(String[] args) throws Exception {
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.get("https://www.dummyticket.com/dummy-ticket-for-visa-application/");
		driver.manage().window().maximize();
		
		driver.findElement(By.xpath("//input[@id='dob']")).click();
		
		//Month and Year Selection
		Select month_drp = new Select(driver.findElement(By.xpath("//select[@aria-label='Select month']")));
		month_drp.selectByVisibleText("Oct");
		//Thread.sleep(1000);
		
		Select year_drp = new Select(driver.findElement(By.xpath("//select[@aria-label='Select year']")));
		year_drp.selectByVisibleText("1990");
		Thread.sleep(1000);
		
		String date = "14";
		
		List<WebElement> alldate = driver.findElements(By.xpath("//table[@class='ui-datepicker-calendar']//td"));
		
		for(WebElement dt : alldate) {
			String getdt = dt.getText();
			if(getdt.equals(date)) {
				dt.click();
				break;
			}
		}
		
	}

}

package DatePicker;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class DatePickerPr {

	public static void main(String[] args) {
	
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.path2usa.com/travel-companions");
		
		//to focus on Date field
		driver.findElement(By.xpath("//input[@id='form-field-travel_comp_date']")).click();
		// to fetch particular date from datepicker
		WebElement activeday=driver.findElement(By.className("active day"));
		List<WebElement> dates=driver.findElements(By.className("day"));
		dates.add(activeday);
		int count=dates.size();
		System.out.println("Total day:"+count);
		
		//24 jan
		
		for(int i=0;i<count;i++)
		{
			String text=dates.get(i).getText();
			if(text.equalsIgnoreCase("24"))
			{
				dates.get(i).click();
				break;
			}
			
		}
		

	}

}

package HandleLinks;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class LocateLinkDemo {

	public static void main(String[] args) {
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.amazon.in/");
		driver.manage().window().maximize();

		// 1 how to locate links in selenium webdriver
		// driver.findElement(By.linkText("Today's Deals")).click();
		// driver.findElement(By.partialLinkText("Deals")).click();

		// How to capture the all links from web pages
		List<WebElement> links = driver.findElements(By.tagName("a"));
		System.out.println("Number of links are :=" + links.size());

		for (int i = 0; i < links.size(); i++) {
			System.out.println(links.get(i).getText());
			System.out.println(links.get(i).getAttribute("href"));
		}

	}

}

package RadioButton;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class RadioButtonDemo {

	public static void main(String[] args) {
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.get("https://rahulshettyacademy.com/AutomationPractice/");
		driver.manage().window().maximize();
		
//		driver.findElement(By.name("radioButton")).click();
//		System.out.println(driver.findElement(By.name("radioButton")).isSelected());
		
		driver.findElement(By.cssSelector("input[value='radio2']")).click();
		System.out.println(driver.findElement(By.cssSelector("input[value='radio2']")).isSelected());
	}

}

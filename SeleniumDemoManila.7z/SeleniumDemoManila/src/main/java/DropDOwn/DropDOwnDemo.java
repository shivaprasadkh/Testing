package DropDOwn;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import io.github.bonigarcia.wdm.WebDriverManager;

public class DropDOwnDemo {

	public static void main(String[] args) {
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.get("https://rahulshettyacademy.com/AutomationPractice/");
		driver.manage().window().maximize();

		WebElement drp = driver.findElement(By.id("dropdown-class-example"));
		Select Selectdrp = new Select(drp);
		// Selectdrp.selectByIndex(1);
		// Selectdrp.selectByValue("option2");
		// Selectdrp.selectByVisibleText("Option3");

//		System.out.println(Selectdrp.getOptions().size());
//		List<WebElement> dropdown = Selectdrp.getOptions();
//
//		for (WebElement opt : dropdown) {
//			System.out.println(opt.getText());
//		}
		
		WebElement firstselectedoption = Selectdrp.getFirstSelectedOption();
		System.out.println(firstselectedoption.getText());
		 

	}

}

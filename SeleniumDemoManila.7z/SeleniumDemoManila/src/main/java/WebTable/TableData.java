package WebTable;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class TableData {

	public static void main(String[] args) {
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.get("https://www.techlistic.com/p/demo-selenium-practice.html");
		driver.manage().window().maximize();

		int rows = driver.findElements(By.xpath("//table[@id='customers']//tbody/tr")).size();
		System.out.println("Number of rows:=" + rows);

		int colms = driver.findElements(By.xpath("//table[@id='customers']//tbody/tr/th")).size();
		System.out.println("Number of columns:=" + colms);

		// retrieve specific row and colm values

		String value1 = driver.findElement(By.xpath("//table[@id='customers']//tr[2]/td[3]")).getText();
		System.out.println(value1);

		String value2 = driver.findElement(By.xpath("//table[@id='customers']//tr[3]/td[1]")).getText();
		System.out.println(value2);

		// Retrieve all the Data from table

		for (int r = 2; r <= rows; r++) { //2,3
			for (int c = 1; c <= colms; c++) { //1,2,3 1,2,3
				String data = driver.findElement(By.xpath("//table[@id='customers']//tr["+r+"]/td["+c+"]")).getText();
				System.out.print(data+" ");
			}
			System.out.println();
		}
	}

}

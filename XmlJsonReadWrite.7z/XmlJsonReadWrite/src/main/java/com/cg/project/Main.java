package com.cg.project;
import java.io.File;
import com.cg.project.iowork.ReadWriteDemo;
public class Main {
	public static void main( String[] args ){
		try {
			/*
			File srcFile = new File("C:\\SatishTrainingData\\Core Java Notes.txt");
			File destFile =  new  File("C:\\SatishTrainingData\\Training Essential data\\"+srcFile.getName());
			ReadWriteDemo.charStreamReadWrite(srcFile, destFile);
			*/
			
			/*
			File file = new File("C:\\BatchData\\EmployeeData.xml");
			ReadWriteDemo.saxParserDemo(file);
			*/
			
			/*
			 * File file = new File("C:\\BatchData\\EmployeeData.xml");
			 * ReadWriteDemo.domParserDemo(file);
			 */
			
			
			/*
			 * File file = new File("C:\\BatchData\\EmployeeData.xml");
			 * ReadWriteDemo.jaxbUnMarshalDemo(file);
			 */
			
			/*
			 File srcFile = new File("C:\\BatchData\\EmployeeData.xml");
			 File destFile = new File("C:\\SatishTrainingData\\"+srcFile.getName());
			 ReadWriteDemo.jaxbMarshalDemo(srcFile,destFile);
			 */
			
			File destFile = new File("C:\\SatishTrainingData\\EmployeeData.json");
			ReadWriteDemo.jsonFileWrite(destFile);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
package com.cg.project.iowork;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Iterator;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.json.JSONWriter;
import org.json.simple.JSONArray;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.cg.project.pojos.Employee;
import com.cg.project.pojos.EmployeeList;
public class ReadWriteDemo {
	public static void byteStreamReadWrite(File srcFile , File destFile) throws IOException {

		// byte stream use 1 byte 1 per char 
		// 1 char at a time will be read and write
		// Topmost parent classes are "InputStream" and "OutputStream"

		FileInputStream inputStream = new FileInputStream(srcFile);
		FileOutputStream outputStream = new FileOutputStream(destFile);
		byte[] dataBuffer = new byte[(int)srcFile.length()];
		inputStream.read(dataBuffer);
		outputStream.write(dataBuffer);
		System.out.println("File has Transfer to "+destFile.getAbsolutePath());
	}
	public static void charStreamReadWrite(File srcFile , File destFile) throws IOException {
		// character stream use 2 byte 1 per char 
		// 1 string at a time will be read and write
		// Topmost parent classes are "Reader" and "Writer"

		BufferedReader reader  =new BufferedReader(new FileReader(srcFile));
		BufferedWriter  writer =  new BufferedWriter(new FileWriter(destFile));
		String data=null;
		while((data= reader.readLine())!=null ) {
			writer.write(data);
		}
		System.out.println("File has Transfer to "+destFile.getAbsolutePath());


	}

	public static void saxParserDemo(File file) {
		try {
			SAXParserFactory  parserFactory = SAXParserFactory.newInstance();
			SAXParser saxParser = parserFactory.newSAXParser();
			saxParser.parse(file, new CustomHandler());	
		} catch (ParserConfigurationException | SAXException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}	
	}

	public static void domParserDemo(File file) {
		try {
			DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newDefaultInstance();
			DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
			Document document = documentBuilder.parse(file);
			document.normalize();

			System.out.println("Root Element	:-	"+ document.getDocumentElement().getNodeName());
			NodeList nodeList = document.getElementsByTagName("Employee");

			for (int i =0;i<nodeList.getLength();i++) {
				Node node = nodeList.item(i);
				if(node.getNodeType()==Node.ELEMENT_NODE) {
					Element element = (Element)node;
					System.out.println("Employee Id 	:-	"+element.getAttribute("id"));
					System.out.println("Salary		:-	"+element.getElementsByTagName("salary").item(0).getTextContent());
					System.out.println("FirstName	:-	"+element.getElementsByTagName("firstName").item(0).getTextContent());
					System.out.println("LastName	:-	"+element.getElementsByTagName("lastName").item(0).getTextContent());

				}
			}
		} catch (ParserConfigurationException | SAXException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}	
	}
	public static void jaxbUnMarshalDemo(File file) {
		try {
			JAXBContext context = JAXBContext.newInstance(EmployeeList.class);
			Unmarshaller unmarshaller = context.createUnmarshaller();
			EmployeeList employeeList = (EmployeeList) unmarshaller.unmarshal(new FileInputStream(file));
			employeeList.getEmployees().forEach(System.out::println);
		} catch (JAXBException e) {
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}		
	}
	public static void jaxbMarshalDemo(File srcFile, File destFile) {
		try {
			JAXBContext context = JAXBContext.newInstance(EmployeeList.class);
			Unmarshaller unmarshaller = context.createUnmarshaller();
			EmployeeList employeeList = (EmployeeList) unmarshaller.unmarshal(new FileInputStream(srcFile));
			Marshaller marshaller = context.createMarshaller();
			marshaller.marshal(employeeList, destFile);

		} catch (JAXBException e) {
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}

	public static void jsonFileRead(File srcFile) {
		try {
			JSONParser jsonParser = new  JSONParser();
			JSONArray jsonArray=	(JSONArray) jsonParser.parse(new FileReader(srcFile));
			for (Object object : jsonArray) 
				System.out.println(object);
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	
	public static void jsonFileWrite(File destFile) {
		try {
			
			Employee employee1 = new Employee(101, 15000, "Kumar", "Rao");
			Employee employee2 = new Employee(102, 3000, "Kumar", "Rao");
			Employee employee3 = new Employee(103, 4000, "Rajesh", "Rao");
			
			JSONArray employeeJsonData = new JSONArray();
			employeeJsonData.add(employee1);
			employeeJsonData.add(employee2);
			employeeJsonData.add(employee3);
			
			FileWriter  fileWriter = new FileWriter(destFile);
			fileWriter.write(employeeJsonData.toJSONString());
			fileWriter.close();
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
	}

}
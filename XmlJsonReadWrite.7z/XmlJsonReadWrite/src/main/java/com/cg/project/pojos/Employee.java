package com.cg.project.pojos;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
public class Employee {
	
	@XmlAttribute
	private int id;
	@XmlElement
	private int salary;
	@XmlElement
	private String firstName;
	@XmlElement
	private String lastName;

	public Employee() {}
	public Employee(int id, int salary, String firstName, String lastName) {
		super();
		this.id = id;
		this.salary = salary;
		this.firstName = firstName;
		this.lastName = lastName;
	}


	@Override
	public String toString() {
		return "Employee [id=" + id + ", salary=" + salary + ", firstName=" + firstName + ", lastName=" + lastName
				+ "]";
	}
}

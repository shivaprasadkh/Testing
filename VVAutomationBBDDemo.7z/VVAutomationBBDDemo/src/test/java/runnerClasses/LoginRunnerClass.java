package runnerClasses;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(features = "C:\\Users\\shivaph\\TestNG\\VVAutomationBBDDemo\\src\\test\\java\\featurefiles\\firstprogram.feature", glue = {
		"stefDefinations" }, monochrome = true, plugin = { "pretty", "junit:target/reports/cucumber.xml", "pretty",
				"json:target/reports/cucumber.json","pretty",  "pretty", "html:target/reports/cucumber.html"})
public class LoginRunnerClass extends AbstractTestNGCucumberTests {

}

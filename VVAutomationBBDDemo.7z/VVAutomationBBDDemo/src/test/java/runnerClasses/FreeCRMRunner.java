package runnerClasses;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(features = "C:\\Users\\shivaph\\TestNG\\VVAutomationBBDDemo\\src\\test\\java\\featurefiles", glue = {
		"stefDefinations" }, monochrome = true, tags="@SmokeTest and @RegressionTesting")// plugin ="html:target/reports_google_freecrm/cucumber.html")
// plugin = { "pretty", "junit:target/reports_google/cucumber.xml", "pretty",
// "json:target/reports_google/cucumber.json", "pretty", "pretty",
// "html:target/reports_google/cucumber.html" })
public class FreeCRMRunner extends AbstractTestNGCucumberTests {

}

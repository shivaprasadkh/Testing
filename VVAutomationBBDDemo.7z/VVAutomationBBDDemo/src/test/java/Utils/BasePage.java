package Utils;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.facebook.customexception.BroswerNotSupportedException;

import io.github.bonigarcia.wdm.WebDriverManager;

public class BasePage {

	public static WebDriver driver;
	Properties prop;
	String browsername;
	public BasePage()
	{
		// allow cross browser testing
		//read the config prop file 
		//acrod key value decide the driver intance to be created
	try {
		prop=new Properties();
		//FileInputStream ip = new FileInputStream(null);
		prop.load(new FileInputStream("config/config.properties"));
		browsername=prop.getProperty("browser");
		
		
		if(browsername.equalsIgnoreCase("chrome"))
			{
			//System.setProperty("webdriver.chrome.driver", "driver/chromedriver.exe");
			WebDriverManager.chromedriver().setup();
			driver=new ChromeDriver();
			}
		else if(browsername.equalsIgnoreCase("firefox"))
		{
			
			WebDriverManager.firefoxdriver().setup();
			//System.setProperty("webdriver.gecko.driver", "driver/.geckodriver.exe");
			driver=new FirefoxDriver();
		}
		else 
		{
			throw new BroswerNotSupportedException("This broswe is not supported for testing this app..."+browsername);
		}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}catch(BroswerNotSupportedException e)
	     {
			e.printStackTrace();
	    }
	
	}
	
	public void loadUrl()
	{
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get(prop.getProperty("url"));
	}
	

	
	
	
	
}

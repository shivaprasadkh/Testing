package Utils;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

public class CaptureScreenShots  {

	//add static fun to capture the screen shots
	
	public static void captureScreen()
	{
		//using TakeScreenShot (I) ref we can call the method
		//getScreenShotas(OutPut<X> target);
		
		try {
		TakesScreenshot ts= (TakesScreenshot)driver;
		
		File f1=ts.getScreenshotAs(OutputType.FILE);
		//need a file copy so that can store this temp f1 in to secondary storage file
		// wil take help of commons io lib 
		FileUtils.copyFile(f1, new File("./screenshots/failedcase.jpg") );
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
}

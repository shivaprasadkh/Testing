package stefDefinations;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginStefDef {
	@Given("User is on NetBanking Landing Page")
	public void user_is_on_net_banking_landing_page() {
		System.out.println("User is on NetBanking Landing Page");
		
	}
	@When("User Login into Application")
	public void user_login_into_application() {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("User Login into Application");
	}
	@Then("Home Pgae is Displayed")
	public void home_pgae_is_displayed() {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("home_pgae_is_displayed");
	}
	@And("Card is displayed")
	public void card_is_displayed() {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("Card is displayed");
	}


}

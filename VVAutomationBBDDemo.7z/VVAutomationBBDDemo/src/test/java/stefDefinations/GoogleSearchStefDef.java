package stefDefinations;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class GoogleSearchStefDef {

	WebDriver driver;

	@Given("User on Goole page")
	public void user_on_goole_page() {
		// Write code here that turns the phrase above into concrete actions

		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.get("https://www.google.com");
	}

//	@When("User enters the search key")
//	public void user_enters_the_search_key() {
//		driver.findElement(By.name("q")).sendKeys("capgemini");
//	}
	
	@When("User enters the search key {string}")
	public void user_enters_the_search_key(String searchItem) {
	    // Write code here that turns the phrase above into concrete actions
		driver.findElement(By.name("q")).sendKeys(searchItem);
	}

	@Then("Display the search result")
	public void display_the_search_result() {
		driver.findElement(By.name("btnK")).submit();
	}

	@And("Close the browser")
	public void close_the_browser() {
		//driver.close();
	}

}

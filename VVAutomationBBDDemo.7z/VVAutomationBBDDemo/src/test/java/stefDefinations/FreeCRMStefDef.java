package stefDefinations;

import static org.testng.Assert.assertEquals;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class FreeCRMStefDef {
	WebDriver driver;

	@Given("User landing on freecrm webpage")
	public void user_landing_on_freecrm_webpage() {
		// Write code here that turns the phrase above into concrete actions
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.get("https://classic.freecrm.com/index.html");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofMillis(1000));
		driver.manage().deleteAllCookies();

	}

	@When("User Enter the username and password")
	public void user_enter_the_username_and_password() {
		// driver.findElement(By.xpath("//input[@placeholder='Username']")).sendKeys("shivucrm");
		// driver.findElement(By.xpath("//input[@placeholder='Password']")).sendKeys("freecrm");
		System.out.println("User Enter the User Name and Password");
	}

//	@When("User Enter the  Username {string} and password {string}")
//	public void user_enter_the_username_and_password(String Username, String Password) {
//	    // Write code here that turns the phrase above into concrete actions
//		driver.findElement(By.xpath("//input[@placeholder='Username']")).sendKeys(Username);
//		driver.findElement(By.xpath("//input[@placeholder='Password']")).sendKeys(Password);
//	}

	@When("^User Enter the  Username (.+) and password (.+)$")
	public void user_enter_the_username_and_password(String Username, String Password) {
		// Write code here that turns the phrase above into concrete actions
		driver.findElement(By.xpath("//input[@placeholder='Username']")).sendKeys(Username);
		driver.findElement(By.xpath("//input[@placeholder='Password']")).sendKeys(Password);
	}

	@Then("User click Login Button")
	public void user_click_login_button() {
		// Write code here that turns the phrase above into concrete actions
		driver.findElement(By.xpath("//input[@value='Login']")).click();
		String actualTitle = "CRMPRO";
		assertEquals(actualTitle, driver.getTitle());

	}

	@And("User navigate to home page")
	public void user_navigate_to_home_page() {
		// Write code here that turns the phrase above into concrete actions
		driver.close();
	}

}

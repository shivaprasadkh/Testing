package com.cg.project.test;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.project.exceptions.NumberRangeException;
import com.cg.project.services.MathService;
import com.cg.project.services.MathServiceImpl;

public class MathServiceTest {
	
	private static MathService mathService;

	@BeforeClass	
	public static void setUpTestEnv(){
		mathService = new MathServiceImpl();
	}
	
	@Test(expected = NumberRangeException.class)
	public void testAddForFirstNumberInvalid() throws NumberRangeException {
		int n1=-100;
		int n2=200;
		mathService.add(n1, n2);		
	}
	
	@Test(expected = NumberRangeException.class)
	public void testAddForSecondNumberInvalid() throws NumberRangeException {
		int n1=100;
		int n2=-200;
		mathService.add(n1, n2);
	}

	@Test
	public void testAddForBothNumberValid() throws NumberRangeException {
		int n1=100;
		int n2=200;
		int expectedAns=300;
		int actualAns=mathService.add(n1, n2);
		Assert.assertEquals(expectedAns, actualAns);
	}

	@AfterClass
	public static void tearDownTestEnv(){
		System.out.println("tearDownTestEnv()");
	}
}

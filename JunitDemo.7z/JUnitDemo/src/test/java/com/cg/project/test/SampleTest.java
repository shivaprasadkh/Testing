package com.cg.project.test;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
public class SampleTest {
	
	//@BeforeClass annotation base method will be executed by JUnit framework only once before all test cases
	//method must be declare static 

	@BeforeClass	
	public static void setUpTestEnv(){
		System.out.println("setUpTestEnv()");
	}
	
	@Before
	public void setUpTestMockDataEnv(){
		System.out.println("setUpTestMockDataEnv()");
	}

	@Test
	public void test1(){
		System.out.println("test1()");
	}

	@Test
	public void test2(){
		System.out.println("test2()");
	}

	@After
	public void tearDownMockDataEnv(){
		System.out.println("tearDownMockDataEnv()");
	}
	
	
	
	//@AfterClass annotation base method will be executed by JUnit framework only once after all test cases
	//method must be declare static 
	@AfterClass
	public static void tearDownTestEnv(){
		System.out.println("tearDownTestEnv()");
	}

}

package com.cg.project.services;
import com.cg.project.exceptions.NumberRangeException;
public class MathServiceImpl implements MathService{
	@Override
	public int add(int n1, int n2) throws NumberRangeException {
		
		return 0;
	}
	
	@Override
	public int sub(int n1, int n2) throws NumberRangeException {
		return 0;
	}

	@Override
	public int div(int n1, int n2) throws NumberRangeException {
		return 0;
	}

	@Override
	public int multi(int n1, int n2) throws NumberRangeException {
		return 0;
	}

}

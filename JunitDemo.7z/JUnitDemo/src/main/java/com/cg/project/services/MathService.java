package com.cg.project.services;

import com.cg.project.exceptions.NumberRangeException;

public interface MathService {
	
	int add(int n1,int n2) throws NumberRangeException;
	int sub(int n1,int n2) throws NumberRangeException;
	int div(int n1,int n2) throws NumberRangeException;
	int multi(int n1,int n2) throws NumberRangeException;

}

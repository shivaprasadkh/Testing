package AlertDemo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Alert {

	public static void main(String[] args) throws Exception {
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.get("https://the-internet.herokuapp.com/javascript_alerts");

		// Alert window with ok Button
		// driver.findElement(By.cssSelector("button[onclick='jsAlert()']")).click();
		// Thread.sleep(2000);
		// driver.switchTo().alert().accept();

		// Alert window with Ok and Cancel Button
		// driver.findElement(By.xpath(" //button[normalize-space()='Click for JS
		// Confirm']")).click();
		// Thread.sleep(4000);
		// driver.switchTo().alert().accept(); //close alert by ok button
		// driver.switchTo().alert().dismiss();

		// Alert Window with inputBox
		driver.findElement(By.xpath("//button[normalize-space()='Click for JS Prompt']")).click();
		Thread.sleep(3000);

		org.openqa.selenium.Alert alertwindow = driver.switchTo().alert();

		System.out.println("The message displayed on alert:" + alertwindow.getText());
		alertwindow.sendKeys("WelCome");
		Thread.sleep(5000);
		alertwindow.accept();

	}

}

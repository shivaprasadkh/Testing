package HandleFrames;
/*driver.switchTo.frame(name of the frame/id of the frame)
 * driver.switchTo.frame(webElement)
 * driver.switchTo.frame(0)
 * 
 * 
 */
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class iFrameDemo {

	public static void main(String[] args) {
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.selenium.dev/selenium/docs/api/java/index.html?org/openqa/selenium/package-summary.html");
		
		driver.manage().window().maximize();
		driver.findElement(By.xpath("//a[normalize-space()='org.openqa.selenium']")).click();
		
	}

}

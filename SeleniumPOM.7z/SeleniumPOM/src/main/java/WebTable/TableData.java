package WebTable;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class TableData {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "C:\\Capgemini\\TESTING\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));

//		 driver.get("https://rahulshettyacademy.com/AutomationPractice/");
//		
// 		String text = driver.findElement(By.xpath("//body[1]/div[3]/div[1]/fieldset[1]/table[1]/tbody[1]/tr[2]/td[1]"))
// 				.getText();
// 		driver.findElement(By.xpath("//body/div[3]/div[1]/fieldset[1]/table[1]"));
// 		System.out.println(text);
//
//		  driver.findElement(By.xpath(" //body/div[3]/div[1]/fieldset[1]/table[1]"))
//
//		  1) How to find rows in a table
//		int rows = driver.findElements(By.xpath("//table[@id='product']//tbody/tr")).size();
//		System.out.println("Total number of rows in Table:" + rows);
//
//		// 1) How to find colms in a table
//		int colms = driver.findElements(By.xpath("//table[@id='product']//tbody/tr/th")).size();
//		System.out.println("Total number of columns in Table:" + colms);
//		

		driver.get("https://www.techlistic.com/p/demo-selenium-practice.html");

		int rows = driver.findElements(By.xpath("//table[@id='customers']//tbody/tr")).size();
		System.out.println("Number of Rows:" + rows);

		int colms = driver.findElements(By.xpath("//table[@id='customers']//tbody/tr/th")).size();
		System.out.println("Number of Columns:" + colms);

		// Retrieve the specific row and Colms Values

//		String value1 = driver.findElement(By.xpath("//table[@id='customers']//tr[2]/td[2]")).getText();
//		System.out.println(value1);
//		String value2 = driver.findElement(By.xpath("//table[@id='customers']//tr[2]/td[3]")).getText();
//		System.out.println(value2);

		// Retrieve all the data from table
//		for (int r = 2; r <= rows; r++) {
//			for (int c = 1; c <= colms; c++) {
//
//				String data = driver.findElement(By.xpath("//table[@id='customers']//tr[" + r + "]/td[" + c + "]"))
//						.getText();
//				System.out.print(data+"   ");
//
//			}
//			System.out.println();
//		}
		
		for(int r=2; r<=rows;r++) {
			String data = driver.findElement(By.xpath("//table[@id='customers']//tr["+r+"]/td[1]")).getText();
			System.out.println(data+"   ");
		}

		driver.quit();

//	JavascriptExecutor	js = (JavascriptExecutor )driver;
//	js.executeScript("alert('hello World');");
	}

}

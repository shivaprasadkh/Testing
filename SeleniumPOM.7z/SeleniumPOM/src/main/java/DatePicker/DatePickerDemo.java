package DatePicker;

import java.text.SimpleDateFormat;
import java.util.Date;

public class DatePickerDemo {
	public static void main(String[] args) throws Exception {
//		WebDriverManager.chromedriver().setup();
//		WebDriver driver = new ChromeDriver();
//		driver.manage().window().maximize();
//		driver.get(null);
		
		String targetDate = "30-Feb-2021";
		SimpleDateFormat targetDateFormat =new SimpleDateFormat("dd-MMM-yyyy");
		Date formattedTargetDate;
		targetDateFormat.setLenient(false);
		formattedTargetDate = targetDateFormat.parse(targetDate);
		System.out.println(formattedTargetDate);
		
		
		
	}

}

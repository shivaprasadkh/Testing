package WindowHandles;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class SwitchingWindows {
	public static void main(String[] args) throws Exception {
		System.setProperty("webdriver.chrome.driver", "C:\\Capgemini\\TESTING\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Windows.html");
		String ParentHandle = driver.getWindowHandle();
		System.out.println("Parent Window:=" + ParentHandle);

		driver.findElement(By.xpath("//a[contains(text(),'Open New Tabbed Windows')]")).click();
		driver.findElement(By.xpath("//button[starts-with(text(),'    click   ')]")).click();
		Thread.sleep(2000);
		// driver.switchTo().window(ParentHandle);
		// System.out.println(driver.getTitle());

		Set<String> ChildHandles = driver.getWindowHandles();

//		for(String handle:ChildHandles) {
//			System.out.println(handle);
//			if(!handle.equals(ParentHandle)  ) {
//				Thread.sleep(2000);
//				
//				driver.switchTo().window(handle);
//				//driver.findElement(By.linkText("Downloads")).click();
//				driver.findElement(By.xpath("/html[1]/body[1]/header[1]/nav[1]/div[1]/ul[1]/li[3]/a[1]/span[1]")).click();
//				driver.quit();
//			}
//		}

		for (String handle : ChildHandles) {
			// System.out.println(handle);
			String child1 = driver.switchTo().window(handle).getTitle();
			// System.out.println(child1);

			if (child1.contains("Selenium")) {
				driver.close();
			}
		}
	}

}

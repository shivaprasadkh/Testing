package FindElementVsFindElements;
/*
 * FindElement() method return the first marching element on the current page
 * if the element is not found it throws NoSuchElementFoundException
 * 
 * findElementd() Methods returns all the matching elements on the current page and 
 * its doenot throw any exception if the element is not found ,
 * instead it will return zero elements 
 * 
 */
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class FindElementsDemos {

	public static void main(String[] args) throws Exception {
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();

		driver.get("https://demo.nopcommerce.com/");
		Thread.sleep(2000);

		// Find Element()-->Returning sigle element
		// 1
		// driver.findElement(By.xpath("//input[@id='small-searchterms']")).sendKeys("Apple");

		// 2
		// WebElement ele =
		// driver.findElement(By.xpath("//div[@class='footer-upper']//a"));
		// System.out.println(ele.getText());

		// 3
		// driver.findElement(By.xpath("//button[normalize-space()='Login']")).click();
		// //NoSuchElementException

		// FindElements()---Return multiple web elements
		// 1
		List<WebElement> element = driver.findElements(By.xpath(" //div[@class='footer-upper']//a"));
		System.out.println("Number of elements are:=" + element.size());

		for (WebElement ele : element) {
			System.out.println(ele.getText());
		}

		// 2
		List<WebElement> logo = driver.findElements(By.xpath("//img[@alt='nopCommerce demo store']"));
		System.out.println("Number of elements are:=" + logo.size());
		
		//3 Noexception
		List<WebElement> elex = driver.findElements(By.xpath("//img[@alt='nopCommerce demo stor']"));
		System.out.println(elex.size());

//		

	}

}

package SeleniumXpaths;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class TestTitle {

	public static void main(String[] args) {

		System.setProperty("webdriver.chrome.driver", "C:\\Capgemini\\TESTING\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.google.com/");
		System.out.println(driver.getTitle());
		boolean title = driver.getTitle().contains("Google");
		if(title) {
			
			System.out.println("Expecte Title is present");
		}	else if(!title)
		{
			System.out.println("Expected title is not present");
		}
		System.out.println(driver.getCurrentUrl());
		//boolean b = driver.getPageSource().contains("Your Text");
		
		driver.quit();

	}
}
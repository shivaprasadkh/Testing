package SeleniumXpaths;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class xPathsDemo {
	public static void main(String[] args) throws Exception {

		System.setProperty("webdriver.chrome.driver","C:\\Capgemini\\TESTING\\chromedriver_win32\\chromedriver.exe");
		 
		WebDriver driver = new ChromeDriver();
 		driver.get("https://demoqa.com/automation-practice-form");
 		
 		driver.findElement(By.cssSelector("li[class='btn btn-light active']")).click();
 		driver.findElement(By.id("firstName")).sendKeys("Shivu",Keys.ENTER);
 		driver.findElement(By.id("lastName")).sendKeys("1234");
 		driver.findElement(By.id("userEmail")).sendKeys("Shivu@gmail.com");
		 
		 
		
		 //driver.quit();
		
	}

}

//////input[contains(@name,"username")]
//Thread.sleep(2000);
//
//driver.findElement(By.xpath("//input[contains(@name,'username')]")).sendKeys("Admin");
//driver.findElement(By.xpath("//input[contains(@name,'password')]")).sendKeys("admin123");
//driver.findElement(By.xpath("//button[contains(@type,'submit')]")).click();
//
//Thread.sleep(2000);
//driver.findElement(By.xpath("//a[.='Admin']")).click();
//Thread.sleep(10000);
////driver.findElement(By.xpath("//input[@xpath='2']")).sendKeys("shiva");
//driver.findElement(By.xpath("//button[contains(.,'Add')]")).click();
//
//Thread.sleep(2000);
//
//WebElement element = driver.findElement(By.xpath("//))
//

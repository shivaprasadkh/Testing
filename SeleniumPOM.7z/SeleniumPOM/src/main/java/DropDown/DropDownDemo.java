package DropDown;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class DropDownDemo {

	public static void main(String[] args) throws Exception {
		System.setProperty("webdriver.chrome.driver", "C:\\Capgemini\\TESTING\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://rahulshettyacademy.com/AutomationPractice/");
		driver.manage().window().maximize();

		Thread.sleep(3000);
		WebElement drp = driver.findElement(By.id("dropdown-class-example"));

		Select selectDrp = new Select(drp);
		selectDrp.selectByIndex(1);
////		 selectDrp.selectByValue(null);
//		 selectDrp.selectByVisibleText("Option2");

		System.out.println(selectDrp.getOptions().size()); // How many options are thr

		List<WebElement> drop = selectDrp.getOptions();
		for (WebElement opt : drop) {
			System.out.println(opt.getText());

		}
		// Radio Button Demo
		driver.findElement(By.name("radioButton")).click();
		System.out.println(driver.findElement(By.name("radioButton")).isSelected());

		// CheckBoxes

		driver.findElement(By.id("checkBoxOption1")).click();
		System.out.println(driver.findElement(By.id("checkBoxOption1")).isSelected());

		//Suggestion Example
		driver.findElement(By.id("autocomplete")).sendKeys("Hi Hello");
		
		
		//Navigation Example
		//driver.navigate().back();
		//driver.navigate().refresh();
		driver.navigate().forward();
		
		
		// driver.quit();
	}

}

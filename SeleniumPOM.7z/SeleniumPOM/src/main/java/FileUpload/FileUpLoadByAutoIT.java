package FileUpload;

public class FileUpLoadByAutoIT {

}

package FileUpload;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class UpLoadFile {
	public static void main(String[] args) throws Exception {
		System.setProperty("webdriver.chrome.driver", "C:\\Capgemini\\TESTING\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://www.monsterindia.com/");
		driver.manage().window().maximize();
		
		driver.findElement(By.xpath("//span[@class='uprcse semi-bold']")).click();
		Thread.sleep(2000);
		//Using Send Key
//		driver.findElement(By.xpath("//input[@id='file-upload']")).sendKeys("C:\\Capgemini\\TESTING\\selenium.txt");
//		
//		driver.findElement(By.xpath("//div[@class='engage w100 fl tc engage-desktop']//div//div[@class='modal-mask']//div[@class='modal-container pr animated upload-resume-modal']//section[@class='modal-body']//div//span[@class='action-cta']")).click();
		
		//Using Roboclass Method
		WebElement  button =  driver.findElement(By.xpath("//input[@id='file-upload']"));
		
		JavascriptExecutor js = (JavascriptExecutor)driver;
		
		js.executeScript("arguments[0].click();", button);
		/*
		 * COpy the pathe
		 * CTR + V
		 * Enter
		 */
		
		
		//driver.quit();

	}

}

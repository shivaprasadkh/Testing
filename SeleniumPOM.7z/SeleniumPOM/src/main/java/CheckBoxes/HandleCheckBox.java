package CheckBoxes;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class HandleCheckBox {

	public static void main(String[] args) {
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.get("https://itera-qa.azurewebsites.net/home/automation");

		// 1 specific check box
		// driver.findElement(By.xpath("//label[normalize-space()='Monday']")).click();

		// 2 select all the check boxes
		List<WebElement> TotalCheckBox = driver
				.findElements(By.xpath("//input[@type='checkbox' and contains (@id,'day')]"));
		System.out.println(TotalCheckBox.size());
//		
//		for(int i =0; i<=TotalCheckBox.size();i++) {
//			TotalCheckBox.get(i).click();
//		}

//		for(WebElement chek:TotalCheckBox ) {
//			chek.click();
//		}

		// 3 Based on My choice select
//		for(WebElement chek:TotalCheckBox ) {
//			
//			String nameofweek  = chek.getAttribute("id");
//			if(nameofweek.equalsIgnoreCase("Monday") || nameofweek.equalsIgnoreCase("Sunday") ) {
//				chek.click();
//			}
//			
//		}

		// Select last two checkBoxes
		// Total no of check boxes -no of check boxes want to select = starting index

		int CheckBoxes = TotalCheckBox.size();
		for (int i = CheckBoxes-2; i < CheckBoxes; i++) {
			TotalCheckBox.get(i).click();

		}

	}

}

package WithOutPoM;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Test_Without_POM {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver","C:\\Capgemini\\TESTING\\chromedriver_win32\\chromedriver.exe");
		 
		 
		//Instantiating chrome driver
		WebDriver driver = new ChromeDriver();
		
		//Opening web application
		driver.get("https://demo.guru99.com/test/login.html");
		
//		//Locating the Login button and clicking on it
//		driver.findElement(By.id("login")).click();
		
		//Locating the username & password and passing the credentials
		driver.findElement(By.id("email")).sendKeys("shiva@prasad");
		driver.findElement(By.id("passwd")).sendKeys("Password@123");
		
//		//Click on the login button
//		driver.findElement(By.id("login")).click();
		
//		//Print the web page heading
//		System.out.println("The page title is : " +driver.findElement(By.xpath("//*[@id=\"app\"]//div[@class=\"main-header\"]")).getText());

		//Click on Logout button
		driver.findElement(By.id("SubmitLogin")).click();
		
		//Close driver instance
		driver.quit();
	}

}

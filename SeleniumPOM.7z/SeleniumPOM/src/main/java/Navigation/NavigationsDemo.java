package Navigation;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;


/*get() is used to navigate particuler RL(Website) and wait till page load driver
 * navigate().to() is used to navigate to perticuler URL and doesnot wait to page laod
 * . it maintains browser history or cookies to navigate back or forward.
 * 
 * 
 * Both the methods are used for opening URL in the browser. There is no difference 
 * between them
 * They are synonyms or one another
 * The only  difference is that can be found in the parameter
 * get() accepts only one string parameter
 * navigate().go() accepts String parameter and URL instance as parameter.
 * 
 */
public class NavigationsDemo {

	public static void main(String[] args) {
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();

		driver.get("https://www.snapdeal.com/");
		//driver.get("https://www.amazon.in/");
		
		driver.navigate().to("https://www.amazon.in/");
		
		driver.navigate().back();  //Snapdeal
		driver.navigate().forward();//Amazon
		
		driver.navigate().refresh();  //Refresh or re load the page
	}

}

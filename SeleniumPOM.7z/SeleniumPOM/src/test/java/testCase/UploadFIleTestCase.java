package testCase;

import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class UploadFIleTestCase {

	@Test
	public void uploadFile() throws Exception {
		System.setProperty("webdriver.chrome.driver", "C:\\Capgemini\\TESTING\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();

		driver.get("https://www.monsterindia.com/");
		driver.manage().window().maximize();

		driver.findElement(By.xpath("//span[@class='uprcse semi-bold']")).click();
		Thread.sleep(2000);

		// *************************Using Send Key
		// **********************************************
		//		driver.findElement(By.xpath("//input[@id='file-upload']")).sendKeys("C:\\Capgemini\\TESTING\\selenium.txt");
		//		
		//	  driver.findElement(By.xpath("//div[@class='engage w100 fl tc engage-desktop']//div//div[@class='modal-mask']//div[@class='modal-container pr animated upload-resume-modal']//section[@class='modal-body']//div//span[@class='action-cta']")).click();
		//	

		//*******************************Using Roboclass Method*******************************
		WebElement button = driver.findElement(By.xpath("//input[@id='file-upload']"));

		JavascriptExecutor js = (JavascriptExecutor) driver;

		js.executeScript("arguments[0].click();", button);
		/*
		 * COpy the pathe CTR + V Enter
		 */
		Robot rb = new Robot();
		rb.delay(2000);
		// put the file in a clipboard
		StringSelection ss = new StringSelection("C:\\Capgemini\\TESTING\\selenium.txt");
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss, null);

		// CTRl+V
		rb.keyPress(KeyEvent.VK_CONTROL); // Press on CTRL key
		rb.keyPress(KeyEvent.VK_V);// Press on CTRL key
		rb.delay(2000);

		rb.keyRelease(KeyEvent.VK_CONTROL);
		rb.keyRelease(KeyEvent.VK_V);
		rb.delay(2000);

		// Enter
		rb.keyPress(KeyEvent.VK_ENTER);
		rb.keyPress(KeyEvent.VK_ENTER);
		driver.findElement(By.xpath(
				"//div[@class='engage w100 fl tc engage-desktop']//div//div[@class='modal-mask']//div[@class='modal-container pr animated upload-resume-modal']//section[@class='modal-body']//div//span[@class='action-cta']"))
		.submit();
		
		
		
		//*****************Using AutoIT**************************************

		// driver.quit();

	}

}

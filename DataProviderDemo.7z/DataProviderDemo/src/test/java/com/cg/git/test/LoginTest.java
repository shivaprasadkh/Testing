package com.cg.git.test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import com.cg.git.dataprovider.MockDataProvider;
import com.cg.git.factory.DriverFactory;
import com.cg.git.pagebeans.LoginPageBean;

public class LoginTest {
	private LoginPageBean pageBean;
	private WebDriver driver;
	@BeforeMethod
	public void beforeMethod() {
		driver = DriverFactory.getDriver();
		pageBean = PageFactory.initElements(driver, LoginPageBean.class);
		driver.get("http://demo.automationtesting.in/SignIn.html");
	}

	
	@Test(dataProviderClass = MockDataProvider.class,dataProvider = "getLoginTestData")    
	public void testLoginForInvalidCredential(String username, String password) {
		
		pageBean.setUsername(username);
		pageBean.setPassword(password);
		pageBean.singIn();
		Assert.assertEquals(pageBean.getErrorMsg(), "Invalid User Name or PassWord");
	}
	
	@Test 
	public void test2() {
		Assert.fail("Test 2 failed");
	}
	
	@Test 
	public void test3() {
		Assert.fail("Test 3 failed");
	}
	
	@AfterMethod
	
	public void afterMethod() {
		driver.quit();
		driver=null;
	}
	
	
}
package com.cg.git.factory;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
public class DriverFactory {
	private static Properties properties;			
	static{
		try {
			properties = new Properties();
			FileInputStream srcStream = new FileInputStream(new File(".//Resources//config.properties"));
			properties.load(srcStream);
			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static WebDriver getDriver() {

		//1st Step register chrome driver .exe  

		String driverName= properties.getProperty("driverName");
		String driverPath= properties.getProperty("driverPath");
		System.setProperty(driverName, driverPath);
	
		//2nd Step create driver instance 

		WebDriver driver=null;
	
			driver = new ChromeDriver();
		
		driver.manage().window().maximize();

		driver.manage().timeouts().pageLoadTimeout(20, TimeUnit.SECONDS);

		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);

		return driver;

	}
}

package com.cg.git.dataprovider;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Iterator;
import java.util.Properties;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.testng.annotations.DataProvider;

public class MockDataProvider {
	
	private static Properties properties;
	static{
		try {
			properties = new Properties();
			properties.load(new FileInputStream(new File(".\\Resources\\config.properties")));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}


	@DataProvider
	public Object [] []  getLoginTestData(){
		Object [] [] mockData=null;
		String filePath = properties.getProperty("filePath");
		String loginTestCase= properties.getProperty("loginTestCase");
		try(Workbook workbook = WorkbookFactory.create(new FileInputStream(new File(filePath)))){
			Sheet workSheet = workbook.getSheet(loginTestCase);
			mockData= new Object[workSheet.getLastRowNum()+1][workSheet.getRow(workSheet.getLastRowNum()).getLastCellNum()];
			
			for(int i =0;i<mockData.length;i++) 
				for(int j=0;j<workSheet.getRow(i).getLastCellNum();j++) 
					mockData [i][j]= workSheet.getRow(i).getCell(j).toString();
			
		} catch (EncryptedDocumentException e) {
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return mockData;
	}
}







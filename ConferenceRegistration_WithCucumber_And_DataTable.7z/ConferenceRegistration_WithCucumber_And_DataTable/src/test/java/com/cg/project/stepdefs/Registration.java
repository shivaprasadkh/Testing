package com.cg.project.stepdefs;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.project.databeans.PaymentBean;
import com.cg.project.databeans.RegistrationBean;
import com.cg.project.factories.DriverFactory;
import com.cg.project.pagebeans.RegistrationPage;
import com.cg.project.stepdefs.Registration;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.DataTableType;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import io.cucumber.java.Scenario;
public class Registration {
	
	private WebDriver driver;
	private RegistrationPage page;
	
	@Before 
	public void setUpSecnarioEnv() {
		driver = DriverFactory.getDriver();
		page = PageFactory.initElements(driver, RegistrationPage.class);
	}
	
	@DataTableType
	public RegistrationBean getRegistrationBean(Map<String, String> entries) {
		RegistrationBean bean = new RegistrationBean();
		bean.setErrorMessage(entries.get("errorMessage")==null ? "" : entries.get("errorMessage"));
		bean.setFirstName(entries.get("firstName")==null ? "" : entries.get("firstName"));
		bean.setLastName(entries.get("lastName")==null ? "" : entries.get("lastName"));
		bean.setEmail(entries.get("email")==null ? "" : entries.get("email"));
		bean.setContactNumber(entries.get("contactNumber")==null ? "" : entries.get("contactNumber"));
		bean.setAddressLine1(entries.get("addressLine1")==null ? "" : entries.get("addressLine1"));
		bean.setAddressLine2(entries.get("addressLine2")==null ? "" : entries.get("addressLine2"));
		bean.setCity(entries.get("city")=="NA" ? "" : entries.get("city"));
		bean.setState(entries.get("state")=="NA" ? "" : entries.get("state"));
		bean.setNumberAttending(entries.get("numberAttending")=="NA" ? "" : entries.get("numberAttending"));
		bean.setAccessLevel(entries.get("accessLevel")=="NA" ? "" : entries.get("accessLevel"));
		bean.setConfirmationMessage(entries.get("validation message")==null ? "" : entries.get("validation message"));
		return bean;
	}
	
	
	
	@Given("user is on the registration page")
	public void user_is_on_the_registration_page() {
	    // Write code here that turns the phrase above into concrete actions
		driver.get("file:///C:/Users/rmatusza/OneDrive%20-%20Capgemini/Documents/technical_training/notes_sdet/docs/conference_booking/ConferenceBooking/ConferenceRegistartion.html");    
	}

	@When("a first name is not entered")
	public void a_first_name_is_not_entered(RegistrationBean registrationBean) {
	   page.setFirstName("");
	    
	}

	@When("the next button is pressed")
	public void the_next_button_is_pressed() {
		   page.setNextButton();

	}

	@Then("the appropriate error message is displayed")
	public void the_appropriate_error_message_is_displayed(RegistrationBean registrationBean) {
		String actualErrorMessage = driver.switchTo().alert().getText();
	    String expectedErrorMessage = registrationBean.getErrorMessage();
	    Assert.assertEquals(expectedErrorMessage, actualErrorMessage);
		driver.switchTo().alert().dismiss();
	    
	}

	@When("a last name is not entered")
	public void a_last_name_is_not_entered(RegistrationBean registrationBean) {
	    page.setFirstName(registrationBean.getFirstName());
	    
	}

	@When("an email is not entered")
	public void an_email_is_not_entered(RegistrationBean registrationBean) {
	   page.setLastName(registrationBean.getLastName());
	    
	}

	@When("a contact number is not entered")
	public void a_contact_number_is_not_entered(RegistrationBean registrationBean) {
	    page.setEmail(registrationBean.getEmail());
	    
	}

	@When("a contact number is formatted incorrectly")
	public void a_contact_number_is_formatted_incorrectly(RegistrationBean registrationBean) {
	   page.setPhone(registrationBean.getContactNumber());
	    
	}

	@When("the number attending is not specified")
	public void the_number_attending_is_not_specified(RegistrationBean registrationBean) {
		page.setPhone("000000000");
	}

	@When("building and room number is not entered")
	public void building_and_room_number_is_not_entered(RegistrationBean registrationBean) {
		 page.setAttendeeNumber();
	}

	@When("area name is not entered")
	public void area_name_is_not_entered(RegistrationBean registrationBean) {
	    page.setAddressL1(registrationBean.getAddressLine1());
	}

	@When("a city is not entered")
	public void a_city_is_not_entered(RegistrationBean registrationBean) {
	  page.setAddressL2(registrationBean.getAddressLine2());
	    
	}

	@When("a state is not entered")
	public void a_state_is_not_entered(RegistrationBean registrationBean) {
	   page.setCity();
	    
	}

	@When("a access level is not entered")
	public void a_access_level_is_not_entered(RegistrationBean registrationBean) {
	    page.setState();
	    
	}

	@When("all of the below data is provided and is in the correct format")
	public void all_of_the_below_data_is_provided_and_is_in_the_correct_format(RegistrationBean registrationBean) {
	  page.setFirstName(registrationBean.getFirstName());
	  page.setLastName(registrationBean.getLastName());
	  page.setFirstName(registrationBean.getFirstName());
	  page.setEmail(registrationBean.getEmail());
	  page.setPhone(registrationBean.getContactNumber());
	  page.setAttendeeNumber();
	  page.setAddressL1(registrationBean.getAddressLine1());
	  page.setAddressL2(registrationBean.getAddressLine2());
	  page.setCity();
	  page.setState();
	  page.setMemberStatus();
	    
	}

	@Then("the appropriate validation message is displayed")
	public void the_appropriate_validation_message_is_displayed_and_user_is_redirected_to(RegistrationBean registrationBean) {
		String actualConfirmationMsg = driver.switchTo().alert().getText();
		String expectedConfirmationMsg = registrationBean.getConfirmationMessage();
		Assert.assertEquals(expectedConfirmationMsg, actualConfirmationMsg);
	}
	
	@After
	public void tearDownScenarioEnv(Scenario scenario) {
//		if(scenario.isFailed()) {
//			TakesScreenshot takesScreenshot = (TakesScreenshot)driver;
//			byte [] screenShot = takesScreenshot.getScreenshotAs(OutputType.BYTES);
//			scenario.embed(screenShot,  "image/png",scenario.getName() );
//		}
		driver.quit();
		driver=null;
	}

}

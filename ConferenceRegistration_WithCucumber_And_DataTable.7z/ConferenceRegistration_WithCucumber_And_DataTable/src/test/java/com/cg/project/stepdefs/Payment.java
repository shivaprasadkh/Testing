package com.cg.project.stepdefs;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.project.databeans.PaymentBean;
import com.cg.project.factories.DriverFactory;
import com.cg.project.pagebeans.PaymentPage;
import com.cg.project.pagebeans.RegistrationPage;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.DataTableType;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.cucumber.java.Scenario;
public class Payment {
	private WebDriver driver;
	private PaymentPage page;
	
	@Before 
	public void setUpSecnarioEnv() {
		driver = DriverFactory.getDriver();
		page = PageFactory.initElements(driver, PaymentPage.class);
	}
	
	@DataTableType
	public PaymentBean getPaymentBean(Map<String, String> entries) {
//		System.out.println("Entries: "+entries);
		PaymentBean bean = new PaymentBean();
		bean.setErrorMessage(entries.get("error message")==null ? "" : entries.get("error message"));
		bean.setFirstName(entries.get("first name")==null ? "" : entries.get("first name"));
		bean.setLastName(entries.get("last name")==null ? "" : entries.get("last name"));
		bean.setCardNumber(entries.get("card number")==null ? "" : entries.get("card number"));
		bean.setCvv(entries.get("cvv")==null ? "" : entries.get("cvv"));
		bean.setExpMonth(entries.get("expiration month")==null ? "" : entries.get("expiration month"));
		bean.setExpYear(entries.get("expiration year")==null ? "" : entries.get("expiration year"));
		bean.setConfirmationMessage(entries.get("confirmation message")==null ? "" : entries.get("confirmation message"));
		System.out.println(bean);
		return bean;
	}
	
	@Given("user is on the payment details page")
	public void user_is_on_the_payment_details_page() {
		driver.get("file:///C:/Users/rmatusza/OneDrive%20-%20Capgemini/Documents/technical_training/notes_sdet/docs/conference_booking/ConferenceBooking/PaymentDetails.html");
	}

	@When("when the user does not enter a first name")
	public void when_the_user_does_not_enter_a_first_name(PaymentBean paymentBean) {
		page.setFirstName("");

	}

	@When("the register button is pressed")
	public void the_register_button_is_pressed() {
		 page.setSubmitButton();
	    
	}

	@Then("the appropriate error message should appear")
	public void the_appropriate_error_message_should_appear(PaymentBean paymentBean) {
		String actualErrorMessage = driver.switchTo().alert().getText();
	    String expectedErrorMessage = paymentBean.getErrorMessage();
	    Assert.assertEquals(expectedErrorMessage, actualErrorMessage);
		driver.switchTo().alert().dismiss();
	    
	}

	@When("when the user does not enter a last name")
	public void when_the_user_does_not_enter_a_last_name(PaymentBean paymentBean) {
		page.setFirstName(paymentBean.getFirstName());

	}

	@When("when the user does not enter a card number")
	public void when_the_user_does_not_enter_a_card_number(PaymentBean paymentBean) {
	    page.setLastName(paymentBean.getLastName());
	}

	@When("wwhen the user does not enter a cvv")
	public void wwhen_the_user_does_not_enter_a_cvv(PaymentBean paymentBean) {
	    page.setDebit(paymentBean.getCardNumber());   
	}

	@When("when the user does not enter an expriation month")
	public void when_the_user_does_not_enter_an_expriation_month(PaymentBean paymentBean) {
	    page.setCvv(paymentBean.getCvv());
	    
	}

	@When("when the user does not enter an expriation year")
	public void when_the_user_does_not_enter_an_expriation_year(PaymentBean paymentBean) {
	    page.setExpMont(paymentBean.getExpMonth());
	}

	@When("the below data is provided and is valid")
	public void the_below_data_is_provided_and_is_valid(PaymentBean paymentBean) {
		page.setFirstName(paymentBean.getFirstName());
	    page.setLastName(paymentBean.getLastName());
	    page.setDebit(paymentBean.getCardNumber());
	    page.setCvv(paymentBean.getCvv());
	    page.setExpMont(paymentBean.getExpMonth());
	    page.setExpYear(paymentBean.getExpYear());
	    
	}

	@Then("a confirmation message should appear")
	public void a_confirmation_message_should_appear(PaymentBean paymentBean) {
		String actualConfirmationMessage = driver.switchTo().alert().getText();
	    String expectedConfirmationMessage = paymentBean.getConfirmationMessage();
	    Assert.assertEquals(expectedConfirmationMessage, actualConfirmationMessage);
		driver.switchTo().alert().dismiss();

	}
	
	@After
	public void tearDownScenarioEnv(Scenario scenario) {
//		if(scenario.isFailed()) {
//			TakesScreenshot takesScreenshot = (TakesScreenshot)driver;
//			byte [] screenShot = takesScreenshot.getScreenshotAs(OutputType.BYTES);
//			scenario.embed(screenShot,  "image/png",scenario.getName() );
//		}
		driver.quit();
		driver=null;
	}

}

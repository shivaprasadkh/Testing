package com.cg.project.databeans;

public class PaymentBean {
	private String errorMessage;
	private String firstName;
	private String lastName;
	private String cardNumber;
	private String cvv;
	private String expMonth;
	private String expYear;
	private String confirmationMessage;
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getCardNumber() {
		return cardNumber;
	}
	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}
	public String getCvv() {
		return cvv;
	}
	public void setCvv(String cvv) {
		this.cvv = cvv;
	}
	public String getExpMonth() {
		return expMonth;
	}
	public void setExpMonth(String expMonth) {
		this.expMonth = expMonth;
	}
	public String getExpYear() {
		return expYear;
	}
	public void setExpYear(String expYear) {
		this.expYear = expYear;
	}
	public String getConfirmationMessage() {
		return this.confirmationMessage;
	}
	public void setConfirmationMessage(String confirmationMessage) {
		this.confirmationMessage = confirmationMessage;
	}
	@Override
	public String toString() {
		return "PaymentBean [errorMessage=" + errorMessage + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", cardNumber=" + cardNumber + ", cvv=" + cvv + ", expMonth=" + expMonth + ", expYear=" + expYear
				+ ", confirmationMessage=" + confirmationMessage + "]";
	}
	
}

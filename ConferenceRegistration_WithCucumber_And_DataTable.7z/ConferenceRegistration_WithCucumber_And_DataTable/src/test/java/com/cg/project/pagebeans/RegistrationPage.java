package com.cg.project.pagebeans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class RegistrationPage {

	
	@FindBy(how = How.XPATH, xpath="/html/body/h4\r\n")
	private WebElement paymentPageTitle;
	
	@FindBy(how = How.XPATH, xpath="/html/body/form/table/tbody/tr[14]/td/a")
	private WebElement nextBtn;
	
	@FindBy(how = How.XPATH, xpath="//html//body//h2")
	private WebElement pageName;
	
	@FindBy(how = How.NAME, name="txtFN")
	private WebElement firstName;
	
	@FindBy(how = How.NAME, name="txtLN")
	private WebElement lastName;
	
	@FindBy(how = How.NAME, name="Email")	
	private WebElement email;
	
	@FindBy(how = How.NAME, name="Phone")	
	private WebElement phone;
	
	@FindBy(how = How.XPATH, xpath="/html/body/form/table/tbody/tr[5]/td[2]/select/option[1]")	
	private WebElement attendeeNumber;
	
	@FindBy(how = How.NAME, name="Address")	
	private WebElement addressL1;
	
	@FindBy(how = How.NAME, name="Address2")	
	private WebElement addressL2;
	
	@FindBy(how = How.XPATH, xpath="/html/body/form/table/tbody/tr[9]/td[2]/select/option[2]")	
	private WebElement city;
	
	@FindBy(how = How.XPATH, xpath="/html/body/form/table/tbody/tr[10]/td[2]/select/option[2]")	
	private WebElement state;
	
	@FindBy(how = How.NAME, name="memberStatus")	
	private WebElement memberStatus;

	public String getPageName() {
		return pageName.getText();
	}

	public void setPageName(String pageName) {
		this.pageName.sendKeys(pageName);
	}

	public String getFirstName() {
		return firstName.getText();
	}

	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName);;
	}

	public String getLastName() {
		return lastName.getText();
	}

	public void setLastName(String lastName) {
		this.lastName.sendKeys(lastName);
	}

	public String getEmail() {
		return email.getText();
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	public String getPhone() {
		return phone.getText();
	}

	public void setPhone(String phone) {
		this.phone.sendKeys(phone);
	}
	
	public String getAttendeeNumber() {
		return this.attendeeNumber.getText();
	}

	public void setAttendeeNumber() {
		this.attendeeNumber.click();
	}

	public String getAddressL1() {
		return addressL1.getText();
	}

	public void setAddressL1(String addressL1) {
		this.addressL1.sendKeys(addressL1);
	}

	public String getAddressL2() {
		return addressL2.getText();
	}

	public void setAddressL2(String addressL2) {
		this.addressL2.sendKeys(addressL2);
	}


	public void setCity() {
		this.city.click();
	}

	public String getState() {
		return state.getText();
	}

	public void setState() {
		this.state.click();
	}

	public String getMemberStatus() {
		return memberStatus.getText();
	}

	public void setMemberStatus() {
		this.memberStatus.click();
	}
	
	public void setNextButton() {
		this.nextBtn.click();
	}
	
	public String getPaymentPageTitle() {
		return this.paymentPageTitle.getText();
	}
		
}

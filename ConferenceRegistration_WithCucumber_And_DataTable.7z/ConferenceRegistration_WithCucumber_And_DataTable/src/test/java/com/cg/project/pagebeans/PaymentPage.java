package com.cg.project.pagebeans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class PaymentPage {
	
	// Registration page elements
	
	@FindBy(how = How.NAME, name="Email")	
	private WebElement email;
	
	@FindBy(how = How.NAME, name="Phone")	
	private WebElement phone;
	
	@FindBy(how = How.NAME, name="Address")	
	private WebElement addressL1;
	
	@FindBy(how = How.NAME, name="Address2")	
	private WebElement addressL2;
	
	@FindBy(how = How.XPATH, xpath="/html/body/form/table/tbody/tr[9]/td[2]/select/option[2]")	
	private WebElement city;
	
	@FindBy(how = How.XPATH, xpath="/html/body/form/table/tbody/tr[10]/td[2]/select/option[2]")	
	private WebElement state;
	
	@FindBy(how = How.NAME, name="memberStatus")	
	private WebElement memberStatus;
	
	@FindBy(how = How.XPATH, xpath="/html/body/form/table/tbody/tr[5]/td[2]/select/option[1]")	
	private WebElement attendeeNumber;
	
	@FindBy(how = How.XPATH, xpath="/html/body/form/table/tbody/tr[14]/td/a")
	private WebElement nextBtn;
	
	
	// Payment page elements
	
	@FindBy(how = How.XPATH, xpath="/html/body/form/table/tbody/tr[7]/td/input")
	private WebElement submitBtn;
	
	@FindBy(how = How.XPATH, xpath="//html//body//h4\r\n")
	private WebElement pageName;
	
	@FindBy(how = How.NAME, name="txtFN")
	private WebElement firstName;
	
	@FindBy(how = How.NAME, name="txtLN")
	private WebElement lastName;
	
	@FindBy(how = How.NAME, name="debit")	
	private WebElement debit;
	
	@FindBy(how = How.NAME, name="cvv")	
	private WebElement cvv;
	
	@FindBy(how = How.NAME, name="month")	
	private WebElement expMont;
	
	@FindBy(how = How.NAME, name="year")	
	private WebElement expYear;
	
	// payment page methods

	public String getPageName() {
		return this.pageName.getText();
	}

	public void setPageName(String pageName) {
		this.pageName.sendKeys(pageName);
	}

	public WebElement getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName);
	}

	public WebElement getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName.sendKeys(lastName);
	}

	public WebElement getDebit() {
		return debit;
	}

	public void setDebit(String debit) {
		this.debit.sendKeys(debit);
	}

	public WebElement getCvv() {
		return cvv;
	}

	public void setCvv(String cvv) {
		this.cvv.sendKeys(cvv);
	}

	public WebElement getExpMont() {
		return expMont;
	}

	public void setExpMont(String expMont) {
		this.expMont.sendKeys(expMont);
	}

	public WebElement getExpYear() {
		return expYear;
	}

	public void setExpYear(String expYear) {
		this.expYear.sendKeys(expYear);
	}
	
	// registration page methods
	
	public void setCity() {
		this.city.click();
	}
	
	public void setState() {
		this.state.click();
	}
	
	public void setMemberStatus() {
		this.memberStatus.click();
	}
	
	public void setAttendeeNumber() {
		this.attendeeNumber.click();
	}
	
	public void setNextButton() {
		this.nextBtn.click();
	}
	
	public void setSubmitButton() {
		this.submitBtn.click();
	}
	
	
}

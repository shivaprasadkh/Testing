package TestNGDemo1;
import org.testng.annotations.Test;

public class TestClass {
	@Test
	public void OpenBrowser() {
		System.out.println("OpenBrowser");
	}
	@Test
	public void Login() {
		System.out.println("Login");
	}
	@Test
	public void Logout() {
		System.out.println("Logout");
	}
}

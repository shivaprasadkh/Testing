package TestNGDemo1;

import org.testng.annotations.Test;

public class TestDemo1 {
	@Test
	public void submit() {
		System.out.println(" Click Submitt");
	}
	@Test
	public void Search() {
		System.out.println(" Click Search");
	}
	 
}

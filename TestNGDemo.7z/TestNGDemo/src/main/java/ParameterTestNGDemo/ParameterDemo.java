package ParameterTestNGDemo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class ParameterDemo {

	WebDriver driver;

	@BeforeTest
	public void InitialiseBrowser() throws InterruptedException {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		// Thread.sleep(3000);
		 driver.get("https://www.facebook.com/");
	}

//	@Parameters("sleepTime")
//	@AfterTest
//	public void TearDown(Long sleepTime) throws Exception {
//		System.out.println(sleepTime);
//		Thread.sleep(sleepTime);
//		driver.quit();
//	}

//	@Parameters("url")
//	@Test
//	public void LaunchApp(String url) throws InterruptedException {
//		driver.get(url);
//		// Thread.sleep(2000);
//
//	}

	@Parameters({ "username", "password" })
	@Test
	public void EnterLoginDetails(String userName, String password) {

		driver.findElement(By.name("email")).sendKeys(userName);
		driver.findElement(By.name("pass")).sendKeys(password);
		driver.findElement(By.name("login")).click();
		System.out.println(driver.getTitle());

	}

}

//<methods>
//<include name="InitialiseBrowser" />
//<include name="EnterLoginDetails" />
//<include name="VerifyLogin" />
//</methods>

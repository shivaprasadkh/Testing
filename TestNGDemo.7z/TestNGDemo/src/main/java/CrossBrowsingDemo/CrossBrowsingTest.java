package CrossBrowsingDemo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class CrossBrowsingTest {
	WebDriver driver = null;
	//String projectpath = System.getProperty("user.dir");

	@Parameters("browserName")
	@BeforeTest
		public void setup(String browserName) {
		System.out.println("Browser Name is :"+browserName);
		System.out.println("Thread id"+Thread.currentThread().getId());
		
		if(browserName.equalsIgnoreCase("chrome"))
		{
			 
			WebDriverManager.chromedriver().setup();
			 driver = new ChromeDriver();
		}else if(browserName.equalsIgnoreCase("firefox")) {
			 
			WebDriverManager.firefoxdriver().setup();
			driver = new FirefoxDriver();
		}else if(browserName.equalsIgnoreCase("edge")) {
			 
			WebDriverManager.edgedriver().setup();
			driver = new EdgeDriver();
	}
	}
	
	@Test
	public void openBrowser() throws Exception {
		
		driver.get("https://www.google.com/");
		driver.findElement(By.name("q")).sendKeys("Capgemini");
		driver.findElement(By.name("btnK")).submit();
		Thread.sleep(3000);
		
	}
	
	@AfterTest
	public void tearDown() {
		driver.quit();
	}
}

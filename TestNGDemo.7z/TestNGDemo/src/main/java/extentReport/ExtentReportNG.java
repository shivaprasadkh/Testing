package extentReport;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
//import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public class ExtentReportNG {
	
	public static ExtentReports getReporterNG() {
		String path = System.getProperty("user.dir"); //+"\\reports\\";
		System.out.println(path);
		ExtentHtmlReporter reporter = new ExtentHtmlReporter("index1.html");
		reporter.config().setReportName("Web Automation results");
		reporter.config().setDocumentTitle("TestResults");

		ExtentReports extent = new ExtentReports();
		extent.attachReporter(reporter);
		extent.setSystemInfo("Tester", "Shivaprasad");
		return extent;
	}

}

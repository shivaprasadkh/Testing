package extentReport;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
//import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import io.github.bonigarcia.wdm.WebDriverManager;

public class ExtentReportDemo {
	ExtentReports extent;

	@BeforeTest
	public void config() {
		// ExtentReports, ExtentSparkReporter

		//String path = System.getProperty("user.dir")+"//reports//index.html";
		//System.out.println(path);
		ExtentHtmlReporter reporter = new ExtentHtmlReporter("index.html");
		reporter.config().setReportName("Web Automation results");
		reporter.config().setDocumentTitle("TestResults");

		extent = new ExtentReports();
		extent.attachReporter(reporter);
		extent.setSystemInfo("Tester", "Shivaprasad");

	}

	@Test
	public void initalDemo() throws Exception {
		com.aventstack.extentreports.ExtentTest test = extent.createTest("Google Site");
		WebDriverManager.firefoxdriver().setup();
		WebDriver driver = new FirefoxDriver();
		driver.get("https://www.google.com/");
		System.out.println(driver.getTitle());
		driver.close();
		//test.addScreenCaptureFromPath("two.png");
		//test.fail("result do not match");
	}
	

	@Test
	public void initalDemo1() throws Exception {
		 extent.createTest("Facebook");
		WebDriverManager.firefoxdriver().setup();
		WebDriver driver = new FirefoxDriver();
		driver.get("https://www.facebook.com/");
		System.out.println(driver.getTitle());
		driver.close();
		//test.addScreenCaptureFromPath("two.png");
		//test.fail("result do not match");
	}
	
	@AfterTest
	public void  teardown() {
		extent.flush();
	}
}

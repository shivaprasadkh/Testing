package FirstTest;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class OrangeHRM {
	WebDriver driver;

	@Test
	public void LaunchApp() throws InterruptedException {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		//Thread.sleep(5000);
	}

	@Test
	public void EnterLoginDetails() throws InterruptedException {
		Thread.sleep(2000);
		driver.findElement(By.name("username")).sendKeys("Admin");
		driver.findElement(By.name("password")).sendKeys("Admin123");
		
//		driver.findElement(By.xpath("xpath=1")).sendKeys("Admin");
//		driver.findElement(ByName("username"))
		
//		 
		driver.findElement(By.tagName("button")).click();
	}

//	@Test
//	public void NavigateToMyInfo() {
//		driver.findElement(By.tagName("span")).click();
//	}

}

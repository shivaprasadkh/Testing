package AnnotationTestNG;

import org.testng.annotations.Test;

public class AnnotationsTestTest {

  @Test
  public void afterClassTest() {
    throw new RuntimeException("Test not implemented");
  }

  @Test
  public void afterMethodTest() {
    throw new RuntimeException("Test not implemented");
  }

  @Test
  public void afterSuiteTest() {
    throw new RuntimeException("Test not implemented");
  }

  @Test
  public void afterTestTest() {
    throw new RuntimeException("Test not implemented");
  }

  @Test
  public void beforeClassTest() {
    throw new RuntimeException("Test not implemented");
  }

  @Test
  public void beforeMethodTest() {
    throw new RuntimeException("Test not implemented");
  }

  @Test
  public void beforeSuiteTest() {
    throw new RuntimeException("Test not implemented");
  }

  @Test
  public void beforeTestTest() {
    throw new RuntimeException("Test not implemented");
  }

  @Test
  public void testMethod1Test() {
    throw new RuntimeException("Test not implemented");
  }

  @Test
  public void testMethod2Test() {
    throw new RuntimeException("Test not implemented");
  }
}

package TestNgDemo;

import org.testng.annotations.Test;

public class TestDemo1 {
	
	@Test 
	public void Submit() {
		System.out.println("ClickSubmit");
	}
	
	@Test
	public void Search() {
		System.out.println("ClickSearch");
	}

}

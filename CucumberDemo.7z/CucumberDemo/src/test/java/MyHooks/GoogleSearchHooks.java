package MyHooks;

import io.cucumber.java.After;
import io.cucumber.java.Before;

public class GoogleSearchHooks {

	@Before(order=1)
	public void setup() {
		System.out.println("Open my Browser");
	}
	@Before(order=2)
	public void setup_url() {
		System.out.println("Url Launched");
	}
	
	
	@After(order=1)
	public void close_B() {
		System.out.println("Closed the Brwoser");
	}
	
	@After(order=2)
	public void Logout() {
		System.out.println("LogOut my Application");
	}
}

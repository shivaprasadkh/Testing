package BackGroundStepDef;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class BackGroundStepDefDemo {

	 @Given("^user is on login page $")
	    public void user_is_on_login_page() throws Throwable {
	    }

	    @When("^user enters username and password $")
	    public void user_enters_username_and_password() throws Throwable {
	    }

	    @When("^user clicks on welcome link $")
	    public void user_clicks_on_welcome_link() throws Throwable {
	    }

	    @When("^user clicks on dashboard link $")
	    public void user_clicks_on_dashboard_link() throws Throwable {
	    }

	    @Then("^user is navigated to the homepage $")
	    public void user_is_navigated_to_the_homepage() throws Throwable {
	    }

	    @Then("^logout link is displayed $")
	    public void logout_link_is_displayed() throws Throwable {
	    }

	    @Then("^quick launch toolbar is displayed $")
	    public void quick_launch_toolbar_is_displayed() throws Throwable {
	    }

	    @And("^clicks on login button $")
	    public void clicks_on_login_button() throws Throwable {
	    }
}

package StepDefinations;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginSteps {
	@Given("^user is on login page$")
    public void user_is_on_login_page() throws Throwable {
		System.out.println("User is on login page");
//		WebDriverManager.chromedriver().setup();
//		WebDriver driver = new ChromeDriver();
//		driver.manage().window().maximize();
//		driver.get("https://www.google.com/");
    }

//	 @When("^user enters \"([^\"]*)\" and \"([^\"]*)\"$")
//    public void user_enters_something_and_something(String strArg1, String strArg2) throws Throwable {
//		System.out.println(strArg1);
//		System.out.println(strArg1);
//    }
//
//    @Then("^user is navigated to home page$")
//    public void user_is_navigated_to_home_page() throws Throwable {
//    	System.out.println("User is onClick Login Button");
//    }
//
//     @And("^click on login button$")
//    public void click_on_login_button() throws Throwable {
//    	System.out.println("Users is on Home Page");
//    }

//	@Given("^user is on login page $")
//	public void user_is_on_login_page() throws Throwable {
//		System.out.println("User is on login page");
//	}

	@When("^user enters username and password$")
	public void user_enters_username_and_password() throws Throwable {
		System.out.println("User Entered password ");
	}
	@And("^click on login button$")
	public void click_on_login_button() throws Throwable {
		System.out.println("User is onClick Login Button");
	}


	@Then("^user is navigated to home page$")
	public void user_is_navigated_to_home_page() throws Throwable {
		System.out.println("Users is in Home Page");
	}


}

//https://regexone.com/
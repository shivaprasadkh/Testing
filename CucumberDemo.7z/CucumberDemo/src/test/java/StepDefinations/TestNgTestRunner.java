package StepDefinations;
import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
@CucumberOptions(features="src\\test\\java\\Features\\LoginNetBanking.feature",
glue={"StepDefinations"},monochrome = true)
public class TestNgTestRunner extends AbstractTestNGCucumberTests{

	 
}

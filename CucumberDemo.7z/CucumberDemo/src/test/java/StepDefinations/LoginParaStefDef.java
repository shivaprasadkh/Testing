package StepDefinations;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class LoginParaStefDef {
	WebDriver driver = null;

	@SuppressWarnings("deprecation")
	@Given("^browser is open for Login$")
	public void browser_is_open_for_login() throws Throwable {
		System.out.println("Inside step-Browser is Open");
		System.out.println("Initilzing Driver");
		//System.setProperty("webdriver.chrome.driver", "C:\\Capgemini\\TESTING\\chromedriver_win32\\chromedriver.exe");
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();

		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);

		driver.manage().window().maximize();
	}

	@And("^user is landed on login page$")
	public void user_is_landed_on_login_page() throws Throwable {
		driver.get("https://example.testproject.io/web/");
		Thread.sleep(2000);
	}

	 @When("^user enters an  (.+)  and  (.+)$")
	public void user_enters_an_something_and_something(String username, String password) {

		driver.findElement(By.id("name")).sendKeys(username);
		driver.findElement(By.id("password")).sendKeys(password);
		 
	}

	@And("^users click on login$")
	public void users_click_on_login() throws Throwable {
		driver.findElement(By.id("login")).click();
		Thread.sleep(2000);
	}

	@Then("^user navigate to the home page next$")
	public void user_navigate_to_the_home_page_next() throws Throwable {
		driver.findElement(By.id("logout")).click();
	}

}

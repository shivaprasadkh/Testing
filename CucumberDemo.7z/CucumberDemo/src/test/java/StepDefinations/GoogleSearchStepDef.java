package StepDefinations;

 

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class GoogleSearchStepDef {
	WebDriver driver = null;
 	 
//	@Before
//	public void init() {
//		System.out.println("Initilzing Driver");
//		System.setProperty("webdriver.chrome.driver", "C:\\Capgemini\\TESTING\\chromedriver_win32\\chromedriver.exe");
//		driver = new ChromeDriver();
//	}

	 
	@Given("^browser is open$")
	public void browser_is_open() throws Throwable {
		System.out.println("Inside step-Browser is Open");
		System.out.println("Initilzing Driver");
		//System.setProperty("webdriver.chrome.driver", "C:\\Capgemini\\TESTING\\chromedriver_win32\\chromedriver.exe");
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		
	 
		
		driver.manage().window().maximize();
		
	}

	@And("^user is on google search page$")
	public void user_is_on_google_search_page() throws Throwable {
		System.out.println("Inside step-User is on Google Search Page");
		//driver.get("https://www.google.com/");
		driver.navigate().to("https://www.google.com/");
	}

	@When("^user enters a text in search box$")
	public void user_enters_a_text_in_search_box() throws Throwable {
		System.out.println("Inside step-User is enter text in search Box");
		
		driver.findElement(By.name("q")).sendKeys("Capgemini");
	}

	@And("^hits enter$")
	public void hits_enter() throws Throwable {
		System.out.println("Inside step-Users Hits");
		driver.findElement(By.name("q")).sendKeys(Keys.ENTER);
		Thread.sleep(3000);
	}

	@Then("^user is navigated to search results$")
	public void user_is_navigated_to_search_results() throws Throwable {
		System.out.println("Inside step-Users navigatesd to Search Box");
		
//		driver.getPageSource().contains("Capgemini - Get The Future You Want");
//		driver.close();
		driver.quit();
	}

}

//package HooksStefDef;
//
//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.chrome.ChromeDriver;
//
//import io.cucumber.java.Before;
//import io.cucumber.java.en.And;
//import io.cucumber.java.en.Given;
//import io.cucumber.java.en.Then;
//import io.cucumber.java.en.When;
//
//public class HooksStefDefDemo {
//	
//	WebDriver driver = null;
//	
//	@Before("@MobileTest")
//	public void browserSetUp() {
//		
////		System.setProperty("webdriver.chrome.driver","C:\\Capgemini\\TESTING\\chromedriver_win32\\chromedriver.exe");
////		 
////		WebDriver driver = new ChromeDriver();
////		driver.get("https://www.google.com/");
//		
//	}
//	@Given("^user is on login page$")
//    public void user_is_on_login_page() throws Throwable {
//    }
//
//    @When("^user enters valid username and password$")
//    public void user_enters_valid_username_and_password() throws Throwable {
//    }
//
//    @Then("^user is navigated to home page$")
//    public void user_is_navigated_to_home_page() throws Throwable {
//    }
//
//    @And("^clicls on login button$")
//    public void clicls_on_login_button() throws Throwable {
//    }
//
//}

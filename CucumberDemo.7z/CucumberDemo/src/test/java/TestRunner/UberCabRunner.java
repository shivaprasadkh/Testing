package TestRunner;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(features = {"src\\test\\java\\Features\\UberBooking.feature"}, 
					glue = { "StepDefinations" }, monochrome = false,
					plugin = {"pretty", "html:target/UberReports"},
					tags="@Test3")
public class UberCabRunner {

}

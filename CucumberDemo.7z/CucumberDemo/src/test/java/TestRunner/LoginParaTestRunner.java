package TestRunner;
import org.junit.runner.RunWith;

import io.cucumber.junit.CucumberOptions;
import io.cucumber.junit.*;

@RunWith(Cucumber.class)
@CucumberOptions(features="src\\test\\java\\Features\\LoginParaDemo.feature",
glue= {"StepDefinations"},monochrome = true,
plugin = {"json","html:target/Html/HtmlReports"})
public class LoginParaTestRunner {
	
	

}
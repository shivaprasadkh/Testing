package TestRunner;

import org.junit.runner.RunWith;

import io.cucumber.junit.CucumberOptions;
import io.cucumber.junit.*;

@RunWith(Cucumber.class)
@CucumberOptions(features = "src\\test\\java\\Features\\GoogleSearch.feature", 
				glue = {"StepDefinations","MyHooks" }, 
				monochrome = true,
				plugin= {"pretty","json:target/JSONReport/report.json"})
public class GoogleSearchTestRunnuer {

}

//plugin = { "pretty", "html:target/reports"}
//plugin = { "pretty", "json:target/reports/cucumber.json"}
//plugin = { "pretty",  "junit:target/reports/cucumber.xml"}
//
//tags="@smoketest"
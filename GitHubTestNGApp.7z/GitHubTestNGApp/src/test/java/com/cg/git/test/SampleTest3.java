package com.cg.git.test;

import org.testng.annotations.Test;

public class SampleTest3 {
	
	@Test
	public void test1() {
		System.out.println("SampleTest3   ----> test1()");
	}
}

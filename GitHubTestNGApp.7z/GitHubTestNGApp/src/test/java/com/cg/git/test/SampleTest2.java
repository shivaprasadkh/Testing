package com.cg.git.test;

import org.testng.annotations.Test;

public class SampleTest2 {

	@Test
	public void test1() {
		System.out.println("SampleTest2   ----> test1()");
	}
}
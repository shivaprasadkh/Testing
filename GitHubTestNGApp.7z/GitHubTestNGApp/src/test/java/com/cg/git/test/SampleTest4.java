package com.cg.git.test;

import org.testng.annotations.Test;

public class SampleTest4 {

	@Test
	public void test1() {
		System.out.println("SampleTest4   ----> test1()");
	}
}

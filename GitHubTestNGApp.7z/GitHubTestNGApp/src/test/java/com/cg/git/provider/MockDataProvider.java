package com.cg.git.provider;

import org.testng.annotations.DataProvider;

public class MockDataProvider {
	
	@DataProvider
	public static Object [] [] loginMockData(){
		return new Object[][] {{"SatishMahajan" ,"Worng Password"}};
	}
}

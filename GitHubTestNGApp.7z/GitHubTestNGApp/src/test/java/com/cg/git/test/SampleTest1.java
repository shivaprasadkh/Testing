package com.cg.git.test;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class SampleTest1 {
	

	
	@Test
	public void test1() {
		System.out.println("SampleTest1   ----> test1()");
	}
}

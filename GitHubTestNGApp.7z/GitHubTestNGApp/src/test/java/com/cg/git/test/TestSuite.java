package com.cg.git.test;

import org.testng.annotations.BeforeSuite;

public class TestSuite {
  
	@BeforeSuite
	 public static void beforeAllTestGroup() {
		System.out.println("TestSuite  -----> beforeAllTestGroup()");
	}
}
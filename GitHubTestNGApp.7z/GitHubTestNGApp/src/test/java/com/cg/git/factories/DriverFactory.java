package com.cg.git.factories;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
public class DriverFactory {
	public static WebDriver  getWebDriver() {
		//1st Step load driver .exe path inside JVM properties
		System.setProperty("webdriver.chrome.driver","C:\\SatishTrainingData\\Training TopicsWise\\SDET\\chromedriver_win32\\chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		//options.addArguments("--headless");
		WebDriver driver = new ChromeDriver(options);
		driver.manage().window().maximize();
		driver.manage().timeouts().pageLoadTimeout(20 , TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		return driver;
	}
}
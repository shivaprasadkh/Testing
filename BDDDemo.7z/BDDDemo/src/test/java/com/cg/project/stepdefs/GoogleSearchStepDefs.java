package com.cg.project.stepdefs;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import com.cg.project.factories.DriverFactory;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class GoogleSearchStepDefs {
	
	WebDriver driver ;
	
	//package ---> io.cucumber.java.Before
	@Before
	public void setUpEnv() {
		driver = DriverFactory.getWebDriver();
	}
	
	@Given("User should open Google search page")
	public void user_should_open_google_search_page() {
	  driver.get("https://www.google.com/");
	}

	@When("User enterd {string} in search box")
	public void user_enterd_in_search_box(String string) {
	  WebElement element = driver.findElement(By.name("q"));
	  element.sendKeys(string);
	}

	@When("click on submit button")
	public void click_on_submit_button() {
		WebElement submitBtn = driver.findElement(By.name("btnK"));
		submitBtn.submit();
	}

	@Then("Multiple Links should be displayed on {string} topic")
	public void multiple_links_should_be_displayed_on_topic(String string) {
		String expectedTitle = string +" - Google Search";
		String actualTitle = driver.getTitle();
		Assert.assertEquals(expectedTitle, actualTitle);
	}

	@When("User enterd cities name {string}  in search box")
	public void user_enterd_cities_name_in_search_box(String string) {
	
	}

	@Then("map should be display between {string} cities along with distance in KM")
	public void map_should_be_display_between_cities_along_with_distance_in_km(String string) {
	 
	}

	@Given("User should open Google translater page")
	public void user_should_open_google_translater_page() {
	 
	}

	@When("User enterd Abstraction word into English  language and select Marathi language")
	public void user_enterd_abstraction_word_into_english_language_and_select_marathi_language() {
	  
	}

	@Then("Google translater should display word Abstraction into Marathi language")
	public void google_translater_should_display_word_abstraction_into_marathi_language() {
	   
	}

	@When("User enterd Fire word into English  language and select French language")
	public void user_enterd_fire_word_into_english_language_and_select_french_language() {
	   
	}

	@Then("Google translater should display word Fire into French language")
	public void google_translater_should_display_word_fire_into_french_language() {

	}

	@When("User enterd Happy word into English  language and select Marathi language")
	public void user_enterd_happy_word_into_english_language_and_select_marathi_language() {

	}

	@Then("Google translater should display word Happy into Marathi language")
	public void google_translater_should_display_word_happy_into_marathi_language() {
	   
	}

	@When("User enterd Sad word into English  language and select Marathi language")
	public void user_enterd_sad_word_into_english_language_and_select_marathi_language() {
	  
	}

	@Then("Google translater should display word Sad into Marathi language")
	public void google_translater_should_display_word_sad_into_marathi_language() {
	  
	}

	@After
	public void tearDownEnv() {
		driver.close();
		driver=null;
	}
}
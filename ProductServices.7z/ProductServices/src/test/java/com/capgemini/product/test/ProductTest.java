package com.capgemini.product.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Test;

import com.capgemini.product.Product;

import ProductDaopk.ProductDao;
import ProductDaopk.ProductDaoImpl;

public class ProductTest {
	
	@Test
	public void createAProduct() {
		ProductDao dao = new ProductDaoImpl();
		Product product = new Product();
		
		product.setId(1);
		product.setName("Iphone");
		product.setDescription("Suprb");
		product.setPrice(500);
		
		dao.create(product);
		Product result = dao.read(1);
		assertNotNull(result);
		assertEquals("Ipad",result.getName());
		
	}

}

package com.cg.project.factories;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
public class DriverFactory {
	public static WebDriver getWebDriver() {
		//1st Load driver
		
		System.setProperty("webdriver.chrome.driver", "C:\\SatishTrainingData\\Training TopicsWise\\SDET\\chromedriver_win32\\chromedriver.exe");

		WebDriver driver = new ChromeDriver();
		
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		
		driver.manage().timeouts().implicitlyWait(30l, TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(30l, TimeUnit.SECONDS);
		
		return driver;
	}
}